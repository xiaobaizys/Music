<template>
  <div class="login">
   <header class="Header">
    <svg class="icon" aria-hidden="true" @click="$router.go(-1)">
      <use xlink:href="#icon-zuojiantou"></use>
    </svg>
   </header>
    <div class="loginTop">登录/注册</div>
    <span class="loginTitle" >新用户验证成功即自动注册</span>
    <div class="loginContent">
      <input
        type="text"
        name="phone"
        class="phone"
        v-model="phone"
        placeholder="请输入手机号码"
      />
      <input
        type="password"
        name="passworld"
        class="passworld"
        v-model="password"
        placeholder="请输入密码"
      />
      <button class="btn" @click="Login">登录</button>
    </div>
    <div class="LoginFooter">
        <input type="checkbox" class="input">  
        <span class="Footer">已阅读并同意</span>
        <span class="link">《用户服务协议》</span>
        <span class="link">《隐私政策》</span>
    </div>
  </div>
</template>
<script>
import {getLoginUser} from '@/request/api/home.js'
export default {
    data(){
        return{
            phone:'',
            password:''
        }
    },
    methods:{
        Login:async function(){
          let res= await this.$store.dispatch('getLogin',{phone:this.phone,password:this.password})
          console.log(res);
          if(res.data.code===200){//如果返回的code等于200，说明登录成功，就跳转个人中心页面
          this.$store.commit('updateIsLogin',true)
          this.$store.commit('updateToken',res.data.token)
          let result=await getLoginUser(res.data.account.id)
          console.log(result);
          this.$store.commit('updateUser',result)
          this.$router.push('/infoUser')
          }else{
              alert("手机号码或者密码错误")
              this.password=''
          }
        }
    }

}
</script>
<style lang="less" scoped>
.login {
  width: 100%;
  height: 13.34rem;
  padding: 0.2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: rgb(247, 246, 246);
  position: relative;
  .Header{
    position: absolute;
    left: 10px;
    top: 10px;

  }
  .loginTop {
    margin-top: 1rem;
    font-size: 0.6rem;
    color: rgb(0, 0, 0);
    margin-bottom: 0.2rem;
  }
  .loginTitle{
    color: #999;
    
  }
  .loginContent {
    width: 100%;
    height: 300px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-around;
    margin-top: 0.2rem;
    .phone,
    .passworld {
      width: 5rem;
      height: 1rem;
      border: 0.02rem solid #999;
      border-radius: 50px;
      padding-left: 35px;
    }
    .btn{
      width: 5rem;
      height: 1rem;
      border-radius: 40px;
      background: #02b5da;
      color: #fff;
      margin-bottom: 22px;
    }
  }
  .LoginFooter{
    font-size: 13px;
    vertical-align:middle;
    display: inline-block;
    .input{
      // zoom:80%;
      vertical-align:middle;
    }
    .Footer{
      display: inline-block;
      padding-left: 6px;
      vertical-align:middle;
    }
    .link{
      color: blue;
      vertical-align:middle;
    }
  }
}
</style>
