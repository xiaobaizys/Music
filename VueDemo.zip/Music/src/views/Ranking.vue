<template>
  <main>
    <header class="Ranking-Header">
      <svg class="icon" aria-hidden="true" @click="$router.go(-1)">
      <use xlink:href="#icon-zuojiantou"></use>
    </svg>
    <h2 style="text-align: center; margin-top: -33px;">排行榜</h2>
    </header>

    <main class="main" v-for="(itemList,index) in list" :key="index">
      <span class="Ranking-Left">
      <img class="image" :src="itemList.src" alt="">
    </span>
      <span class="Ranking-Right">
        <span class="titleTop">
          {{ itemList.titleTop }}
          <span class="titleBottom"> {{ itemList.titleBottom }}
            <span class="titleRight">{{ itemList.titleRight }}</span>
          </span> 
        </span>
      </span>
    </main>
    

  </main>
</template>

<script>
export default{
  data(){
        return{
            list:[
              {
                src: 'https://p1.music.126.net/p0X5QPTfIZKmwXP9UJIaFA==/109951168038961135.jpg?param=140y140',
                titleTop:'粤听粤爱 | 品味经典粤语 唱尽世间人生百态',
                titleBottom:'by 月亮藏不住的小情绪',
                titleRight:'9452人关注'
              },

              {
                src: 'https://p1.music.126.net/L9o79rTIcDWczQSJtpU2Tg==/109951167933404557.jpg?param=140y140',
                titleTop:'Chill Time丨浸润于夜色中的一抹寂静',
                titleBottom:'by 丨IIIIIIIIII丨 ',
                titleRight:'5453人关注'
              },

              {
                src: 'https://p1.music.126.net/JcpOXM243FptA9tRYnPFlw==/109951167423159409.jpg?param=140y140',
                titleTop:'猫咪喜欢的轻音乐 持续更新 『猫咪喜欢的轻音乐』',
                titleBottom:'by 冰美式三分苦加浓 ',
                titleRight:'7543人关注'
              },

              {
                src: 'https://p2.music.126.net/TYWStaUhjbDItMWVB1MlHw==/109951168021508669.jpg?param=140y140',
                titleTop:'民谣有三 远方很美，不怕天黑 【民谣有三 ³】',
                titleBottom:'by 倾天奏梦 ',
                titleRight:'2543人关注'
              },

              {
                src: 'https://p2.music.126.net/BOtEmpSRyhrGI7HXDD0qZQ==/109951168168765433.jpg?param=140y140',
                titleTop:'华语经典顶流作品合集｜首首经典无损SQ',
                titleBottom:'内啡肽_Fentany丨 ',
                titleRight:'7533人关注'
              },

              {
                src: 'https://p2.music.126.net/VGlVCZxFOxFnToMj2YhNWw==/109951167965172265.jpg?param=140y140',
                titleTop:'37.2°C电子❀遐想氛围，微醺治愈',
                titleBottom:'Martin网易云Carlos ',
                titleRight:'3243人关注'
              },

              {
                src: 'https://p2.music.126.net/TYWStaUhjbDItMWVB1MlHw==/109951168021508669.jpg?param=140y140',
                titleTop:'民谣有三 远方很美，不怕天黑 【民谣有三 ³】',
                titleBottom:'by 倾天奏梦 ',
                titleRight:'2543人关注'
              },

              {
                src: 'https://p1.music.126.net/L9o79rTIcDWczQSJtpU2Tg==/109951167933404557.jpg?param=140y140',
                titleTop:'Chill Time丨浸润于夜色中的一抹寂静',
                titleBottom:'by 丨IIIIIIIIII丨 ',
                titleRight:'5453人关注'
              },

              {
                src: 'https://p1.music.126.net/p0X5QPTfIZKmwXP9UJIaFA==/109951168038961135.jpg?param=140y140',
                titleTop:'粤听粤爱 | 品味经典粤语 唱尽世间人生百态',
                titleBottom:'by 月亮藏不住的小情绪',
                titleRight:'9452人关注'
              },

              {
                src: 'https://p1.music.126.net/JcpOXM243FptA9tRYnPFlw==/109951167423159409.jpg?param=140y140',
                titleTop:'猫咪喜欢的轻音乐 持续更新 『猫咪喜欢的轻音乐』',
                titleBottom:'by 冰美式三分苦加浓 ',
                titleRight:'7543人关注'
              },


            ]
        }
    },
}
</script>

<style lang="less" scoped>

.Ranking-Header{
  margin: 7px 7px;
}

.main{
  
  width: 95%;
  height: 60px;
  margin-left: 10px;
  margin-right: 10px;
  border-radius: 10px;
  background-color: rgb(220, 220, 220);
  padding: 5px;
  margin-bottom: 15px;
  .Ranking-Left{
  
  .image{
    width: 50px;
    height: 50px;
    margin: 0 15px;
    vertical-align: middle;
    float: left;
  }
 }

 .Ranking-Right{
  .titleTop{
    font-size: 16px;
    display: block;
    margin: 6px 0;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }

  .titleBottom{
   display: block;
    font-size: 14px;
    color:#878787
  }
  .titleRight{
    float: right;
    margin-right: 25px;
    color: #a6a6a6;
  }
 
 }
}
</style>