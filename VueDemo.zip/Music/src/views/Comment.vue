<template>
  <main class="header-container"> 
   <header class="header-comment">
     <svg class="icon" aria-hidden="true" @click="$router.go(-1)">
     <use xlink:href="#icon-zuojiantou"></use>
   </svg>
   </header>

    <div class="header-avatar">
      <img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fm.imeitou.com%2Fuploads%2Fallimg%2F160727%2F3-160HF95956.gif&refer=http%3A%2F%2Fm.imeitou.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1674750730&t=091170301cbbb4d2de1fa6d846cc008a" alt="" style="width: 52px; height: 60px; border-radius: 50%;     margin-bottom: -22px;">
      <span>用户名 : </span>
   
      <input style="height: 25px; border-radius: 10px; background-color: #f3f3f3;padding:  6px;font-size: 18px; " v-model.trim="user" @keyup.enter="addItem()" type="text" placeholder="用户名" />
    </div>
    <br>
    <hr>

    <div class="header-main">
      
      <p>评论&nbsp;&nbsp;<span class="span-left">8888</span> &nbsp;&nbsp;&nbsp;<span class="span-right">最热 | </span> <span class="sapn-show" style="font-size: 15px;">最新</span></p>
      <br>
      <textarea  v-model="comm" @keyup.enter="addItem()" placeholder="请输入评论"></textarea>
      <button  class="btn"  @click="btn">发表评论</button>
    </div>

    
    <div class="header-comments">
     
      <ul>
        <li v-for="(item,index) in list" :key="item.name" style="position: relative;">
          <img src="https://img1.baidu.com/it/u=38051914,745056107&fm=253&fmt=auto&app=120&f=JPEG?w=800&h=802" alt="">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.name}}&nbsp;说：{{item.txt}}
          <a class="delete" href="#" @click="delItem(item)">删除</a>
      </li>
      </ul>
    </div>
   </main>
</template>
<script>
export default {
 data(){
return{
   msg: '',
   list : [
       {name:"小酷狗",txt:"睡觉算什么，有本事你别醒。"},
       {name:"大微信",txt:"屁屁点点通，一看好轻松。"},
       {name:"小爱同学",txt:"你好,我是小爱同学"},
       {name:"小度",txt:"可恶，有被装到"},
       {name:"我是复制",txt:"我是粘贴"}
   ],
   user:"",//输入的名字存入
   comm:"",//评论存入
}
         },
methods:{
           
           btn(){
               var usercom={
                 name:this.user,
                 txt:this.comm
               }
               this.list.unshift(usercom)
               this.user="";
               this.comm="";
             },
           addItem(){
               var item={
                   name:this.user,
                   // 用户评论
                   txt:this.comm,
               };
                // 在list前面添加 item    unshift在前面添加
                   this.list.unshift(item)

                   // 清空user
                   this.user="";
                   // 清空评论
                   this.comm="";
           },
           delItem(item){
           // 查找元素item在list里的下标
           var ind=this.list.findIndex(value=>value.name==item.name);
           //删除
           // splice 功能（从第几个元素，删除几个 添加内容）
           this.list.splice(ind,1);
           }
           
     }
}
</script>

<style lang="less" scoped>

 
 *{
     padding: 0;
     margin: 0;
     list-style: none;
     text-decoration: none;
 }


 

 .header-container .header-avatar span{
   margin: 0 15px;
   font-size: 20px;
 }
 .header-container .header-main{
 position: relative;
 }
 .header-container p{
 font-size: 25px;
 font-weight: 500;
 cursor: pointer;
 }
 .header-container p .span-left , .span-right{
   font-size: 15px;
   color: #c2b9b0;
   cursor: pointer;
 }
 .header-container p .span-show{
   font-weight: 500;
   font-size: 15px;
   cursor: pointer;
 }
 .header-container textarea{
 
 height: 48px;
 width: 78%;
 resize: none;
 outline: none;
 background-color: #f3f3f3;
 border-radius: 10px;
 padding: 5px 6px 5px 6px;
 font-size: 20px;
 font-weight: bold;
 margin-left: 6px;
 line-height: 36px;
 }
 .header-container textarea:hover{
 background-color: #fff;
 }
 .header-container .btn{
 width: 73px;
 height: 50px;
 border-radius: 10px;
 position: absolute;
 background-color: #2381c9;
 color: #fff;
 border: 1px solid #fff;
 bottom: 2px;
 margin-left: 5px;
 
 /* line-height: 62px; */
 }   
 .header-container .btn:hover{
     background-color: #72afd4;
 }
 .header-container  li{
     border: 1px solid #fff;
 }
 .header-container .header-comments li{
     width: auto;
     height: 70px;
    
     padding: 6px 5px;
     border-radius: 10px;
     margin: 15px 5px;
     /* border: 1px solid lightgreen; */
     background-color: #f0f0f0;
 }
 .header-container .header-comments li:hover{
     background-color: #fdf6f6;
 }
 .header-container .header-comments li img{
     width: 45px; 
     height: 40px; 
     border-radius: 50%; 
     line-height: 40px;
     vertical-align: text-top; 
     padding-top: -3px;
     position: absolute;
     top: -3px;
     
 }
 .header-container .header-comments li .delete{
     color: #c2b9b0;
     position: absolute;
     right: 0;
     bottom: 0;
 }
 .header-container .header-comments li .delete:hover{
     color: red;
 }
 
  
</style>