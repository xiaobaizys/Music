# wangyiyun-zys

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### 使用的技术栈
 vue3 + axios + vuex + vant + 网易云api 

